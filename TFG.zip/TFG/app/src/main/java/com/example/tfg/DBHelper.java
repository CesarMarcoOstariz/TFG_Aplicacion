package com.example.tfg;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "mi_app.db";
    private static final int DATABASE_VERSION = 2;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE usuarios (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT," +
                "apodo TEXT," +
                "edad INTEGER," +
                "contraseña TEXT," +
                "imagen BLOB)");


        db.execSQL("CREATE TABLE actividades (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT," +
                "ciudad TEXT," +
                "fecha TEXT," +
                "hora TEXT," +
                "lugar TEXT," +
                "descripcion TEXT)");

        db.execSQL("CREATE TABLE comentarios_actividad (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "idUsuario INTEGER," +
                "idActividad INTEGER," +
                "texto TEXT," +
                "fecha TEXT)");

        db.execSQL("CREATE TABLE comentarios_perfil (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "idUsuarioAutor INTEGER," +
                "idUsuarioDestino INTEGER," +
                "texto TEXT," +
                "fecha TEXT)");

        db.execSQL("CREATE TABLE usuario_actividades (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "idUsuario INTEGER," +
                "idActividad INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS usuarios");
        db.execSQL("DROP TABLE IF EXISTS actividades");
        db.execSQL("DROP TABLE IF EXISTS comentarios_actividad");
        db.execSQL("DROP TABLE IF EXISTS comentarios_perfil");
        db.execSQL("DROP TABLE IF EXISTS usuario_actividades");
        onCreate(db);
    }

    public long insertarUsuario(String nombre, String apodo, int edad, String contraseña) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", nombre);
        values.put("apodo", apodo);
        values.put("edad", edad);
        values.put("contraseña", contraseña);
        long id = db.insert("usuarios", null, values);
        db.close();
        return id;
    }

    public boolean comprobarLogin(String apodo, String contraseña) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM usuarios WHERE apodo=? AND contraseña=?",
                new String[]{apodo, contraseña}
        );
        boolean existe = cursor.moveToFirst();
        cursor.close();
        db.close();
        return existe;
    }

    public int obtenerIdUsuario(String apodo, String contraseña) {
        int userId = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT id FROM usuarios WHERE apodo=? AND contraseña=?",
                new String[]{apodo, contraseña}
        );
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return userId;
    }

    public long insertarActividad(String nombre, String ciudad, String fecha,
                                  String hora, String lugar, String descripcion) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", nombre);
        values.put("ciudad", ciudad);
        values.put("fecha", fecha);
        values.put("hora", hora);
        values.put("lugar", lugar);
        values.put("descripcion", descripcion);
        long id = db.insert("actividades", null, values);
        db.close();
        return id;
    }

}
