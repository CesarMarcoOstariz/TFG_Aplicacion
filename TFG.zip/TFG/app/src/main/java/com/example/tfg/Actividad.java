package com.example.tfg;

public class Actividad {
    private int id;
    private String nombre;
    private String ciudad;
    private String fecha;
    private String hora;
    private String lugar;
    private String descripcion;

    public Actividad(int id, String nombre, String ciudad, String fecha, String hora, String lugar, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.fecha = fecha;
        this.hora = hora;
        this.lugar = lugar;
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public String getLugar() {
        return lugar;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
