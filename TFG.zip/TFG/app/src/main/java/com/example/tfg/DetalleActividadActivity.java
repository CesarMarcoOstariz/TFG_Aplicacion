package com.example.tfg;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DetalleActividadActivity extends AppCompatActivity {
    private TextView tvNombreAct, tvCiudadAct, tvFechaAct, tvHoraAct, tvLugarAct, tvDescAct;
    private Button btnApuntarse, btnDesapuntarse, btnVolver, btnAgregarComentario;
    private RecyclerView rvComentarios;
    private DBHelper dbHelper;
    private int idActividad, idUsuario;
    private boolean estaApuntado = false;

    private List<Comentario> listaComentarios = new ArrayList<>();
    private ComentarioAdapter comentarioAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_actividad);

        tvNombreAct = findViewById(R.id.tvNombreAct);
        tvCiudadAct = findViewById(R.id.tvCiudadAct);
        tvFechaAct = findViewById(R.id.tvFechaAct);
        tvHoraAct = findViewById(R.id.tvHoraAct);
        tvLugarAct = findViewById(R.id.tvLugarAct);
        tvDescAct = findViewById(R.id.tvDescAct);
        btnApuntarse = findViewById(R.id.btnApuntarse);
        btnDesapuntarse = findViewById(R.id.btnDesapuntarse);
        btnVolver = findViewById(R.id.btnVolver);
        btnAgregarComentario = findViewById(R.id.btnAgregarComentario);
        rvComentarios = findViewById(R.id.rvComentarios);

        dbHelper = new DBHelper(this);
        idActividad = getIntent().getIntExtra("idActividad", -1);
        SharedPreferences prefs = getSharedPreferences("MisPrefs", MODE_PRIVATE);
        idUsuario = prefs.getInt("idUsuarioLogueado", -1);

        comentarioAdapter = new ComentarioAdapter(listaComentarios);
        rvComentarios.setAdapter(comentarioAdapter);
        rvComentarios.setLayoutManager(new LinearLayoutManager(this));

        btnApuntarse.setOnClickListener(v -> apuntarseActividad());
        btnDesapuntarse.setOnClickListener(v -> desapuntarseActividad());
        btnAgregarComentario.setOnClickListener(v -> mostrarDialogoAgregarComentario());
        btnVolver.setOnClickListener(v -> finish());

        cargarDatosActividad(idActividad);
        verificarSiEstaApuntado();
        cargarComentarios();
    }

    private void cargarDatosActividad(int idAct) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM actividades WHERE id=?", new String[]{String.valueOf(idAct)});

        if (cursor.moveToFirst()) {
            tvNombreAct.setText(cursor.getString(cursor.getColumnIndexOrThrow("nombre")));
            tvCiudadAct.setText(cursor.getString(cursor.getColumnIndexOrThrow("ciudad")));
            tvFechaAct.setText(cursor.getString(cursor.getColumnIndexOrThrow("fecha")));
            tvHoraAct.setText(cursor.getString(cursor.getColumnIndexOrThrow("hora")));
            tvLugarAct.setText(cursor.getString(cursor.getColumnIndexOrThrow("lugar")));
            tvDescAct.setText(cursor.getString(cursor.getColumnIndexOrThrow("descripcion")));
        }

        cursor.close();
        db.close();
    }

    private void verificarSiEstaApuntado() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM usuario_actividades WHERE idUsuario=? AND idActividad=?",
                new String[]{String.valueOf(idUsuario), String.valueOf(idActividad)});

        if (cursor.moveToFirst() && cursor.getInt(0) > 0) {
            estaApuntado = true;
        }

        cursor.close();
        db.close();
        actualizarBotones();
    }

    private void actualizarBotones() {
        if (estaApuntado) {
            btnApuntarse.setVisibility(Button.GONE);
            btnDesapuntarse.setVisibility(Button.VISIBLE);
        } else {
            btnApuntarse.setVisibility(Button.VISIBLE);
            btnDesapuntarse.setVisibility(Button.GONE);
        }
    }

    private void apuntarseActividad() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("idUsuario", idUsuario);
        values.put("idActividad", idActividad);

        long resultado = db.insert("usuario_actividades", null, values);
        db.close();

        if (resultado != -1) {
            Toast.makeText(this, "Te has apuntado a la actividad", Toast.LENGTH_SHORT).show();
            estaApuntado = true;
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Error al apuntarse", Toast.LENGTH_SHORT).show();
        }
    }

    private void desapuntarseActividad() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int deleted = db.delete("usuario_actividades", "idUsuario=? AND idActividad=?",
                new String[]{String.valueOf(idUsuario), String.valueOf(idActividad)});
        db.close();

        if (deleted > 0) {
            Toast.makeText(this, "Te has desapuntado correctamente", Toast.LENGTH_SHORT).show();
            estaApuntado = false;
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Error al desapuntarse", Toast.LENGTH_SHORT).show();
        }
    }

    private void cargarComentarios() {
        listaComentarios.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT texto FROM comentarios WHERE idActividad=?",
                new String[]{String.valueOf(idActividad)});

        while (cursor.moveToNext()) {
            listaComentarios.add(new Comentario(cursor.getString(0)));
        }

        cursor.close();
        db.close();
        comentarioAdapter.notifyDataSetChanged();
    }

    private void mostrarDialogoAgregarComentario() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Nuevo Comentario");

        final EditText input = new EditText(this);
        input.setHint("Escribe tu comentario");
        builder.setView(input);

        builder.setPositiveButton("Agregar", (dialog, which) -> {
            String texto = input.getText().toString().trim();
            if (!texto.isEmpty()) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("idUsuario", idUsuario);
                values.put("idActividad", idActividad);
                values.put("texto", texto);
                db.insert("comentarios", null, values);
                db.close();
                cargarComentarios();
                Toast.makeText(this, "Comentario agregado", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }
}
