package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistroActivity extends AppCompatActivity {
    private EditText etNombre, etApodo, etEdad, etContrasena;
    private Button btnRegistrar;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        dbHelper = new DBHelper(this);
        etNombre = findViewById(R.id.etNombre);
        etApodo = findViewById(R.id.etApodo);
        etEdad = findViewById(R.id.etEdad);
        etContrasena = findViewById(R.id.etContrasena);
        btnRegistrar = findViewById(R.id.btnRegistrar);

        btnRegistrar.setOnClickListener(view -> {
            String nombre = etNombre.getText().toString().trim();
            String apodo = etApodo.getText().toString().trim();
            int edad = Integer.parseInt(etEdad.getText().toString().trim());
            String contrasena = etContrasena.getText().toString().trim();

            long id = dbHelper.insertarUsuario(nombre, apodo, edad, contrasena);
            if (id > 0) {
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error en registro", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
