package com.example.tfg;

public class Comentario {
    private String texto;

    public Comentario(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }
}
