package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Calendar;

public class CrearActividadActivity extends AppCompatActivity {
    private EditText etNombreAct, etCiudadAct, etFechaAct, etHoraAct, etLugarAct, etDescAct;
    private Button btnCrear, btnCalendario;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_actividad);

        etNombreAct = findViewById(R.id.etNombreAct);
        etCiudadAct = findViewById(R.id.etCiudadAct);
        etFechaAct = findViewById(R.id.etFechaAct);
        etHoraAct = findViewById(R.id.etHoraAct);
        etLugarAct = findViewById(R.id.etLugarAct);
        etDescAct = findViewById(R.id.etDescAct);
        btnCrear = findViewById(R.id.btnCrear);
        btnCalendario = findViewById(R.id.btnCalendario);

        dbHelper = new DBHelper(this);

        // Calendario para seleccionar fecha
        btnCalendario.setOnClickListener(v -> {
            final Calendar calendario = Calendar.getInstance();
            int anio = calendario.get(Calendar.YEAR);
            int mes = calendario.get(Calendar.MONTH);
            int dia = calendario.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    CrearActividadActivity.this,
                    (view, year, month, dayOfMonth) -> {
                        String fechaSeleccionada = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                        etFechaAct.setText(fechaSeleccionada);
                    },
                    anio, mes, dia
            );
            datePickerDialog.show();
        });

        btnCrear.setOnClickListener(v -> {
            String nombre = etNombreAct.getText().toString().trim();
            String ciudad = etCiudadAct.getText().toString().trim();
            String fecha = etFechaAct.getText().toString().trim();
            String hora = etHoraAct.getText().toString().trim();
            String lugar = etLugarAct.getText().toString().trim();
            String desc = etDescAct.getText().toString().trim();

            long id = dbHelper.insertarActividad(nombre, ciudad, fecha, hora, lugar, desc);
            if (id > 0) {
                Toast.makeText(this, "Actividad creada", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error al crear actividad", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
