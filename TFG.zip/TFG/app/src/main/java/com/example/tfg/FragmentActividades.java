package com.example.tfg;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import java.util.ArrayList;

public class FragmentActividades extends Fragment {
    private EditText etFiltroNombre, etFiltroCiudad;
    private Button btnCrearAct;
    private RecyclerView rvActividades;
    private ActividadesAdapter adapter;
    private ArrayList<Actividad> listaActividades;
    private DBHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_actividades, container, false);

        etFiltroNombre = view.findViewById(R.id.etFiltroNombre);
        etFiltroCiudad = view.findViewById(R.id.etFiltroCiudad);
        btnCrearAct = view.findViewById(R.id.btnCrearAct);
        rvActividades = view.findViewById(R.id.rvActividades);

        dbHelper = new DBHelper(getContext());
        listaActividades = new ArrayList<>();
        rvActividades.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ActividadesAdapter(listaActividades, getContext());
        rvActividades.setAdapter(adapter);

        cargarActividades("", "");

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String nombre = etFiltroNombre.getText().toString();
                String ciudad = etFiltroCiudad.getText().toString();
                cargarActividades(nombre, ciudad);
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
        };
        etFiltroNombre.addTextChangedListener(textWatcher);
        etFiltroCiudad.addTextChangedListener(textWatcher);

        btnCrearAct.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), CrearActividadActivity.class);
            startActivity(intent);
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        String nombre = etFiltroNombre.getText().toString();
        String ciudad = etFiltroCiudad.getText().toString();
        cargarActividades(nombre, ciudad);
    }

    private void cargarActividades(String nombreFiltro, String ciudadFiltro) {
        listaActividades.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM actividades WHERE nombre LIKE ? AND ciudad LIKE ?",
                new String[]{"%" + nombreFiltro + "%", "%" + ciudadFiltro + "%"}
        );
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombre"));
                String ciudad = cursor.getString(cursor.getColumnIndexOrThrow("ciudad"));
                String fecha = cursor.getString(cursor.getColumnIndexOrThrow("fecha"));
                String hora = cursor.getString(cursor.getColumnIndexOrThrow("hora"));
                String lugar = cursor.getString(cursor.getColumnIndexOrThrow("lugar"));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow("descripcion"));
                listaActividades.add(new Actividad(id, nombre, ciudad, fecha, hora, lugar, desc));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        adapter.notifyDataSetChanged();
    }
}
