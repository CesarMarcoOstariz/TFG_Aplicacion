package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;

public class LoginActivity extends AppCompatActivity {
    private EditText etApodo, etContrasena;
    private Button btnIniciar, btnRegistrar;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DBHelper(this);
        etApodo = findViewById(R.id.etApodo);
        etContrasena = findViewById(R.id.etContrasena);
        btnIniciar = findViewById(R.id.btnIniciarSesion);
        btnRegistrar = findViewById(R.id.btnRegistrarse);

        btnIniciar.setOnClickListener(view -> {
            String apodo = etApodo.getText().toString().trim();
            String contrasena = etContrasena.getText().toString().trim();

            if (dbHelper.comprobarLogin(apodo, contrasena)) {
                int userId = dbHelper.obtenerIdUsuario(apodo, contrasena);
                if (userId != -1) {
                    SharedPreferences prefs = getSharedPreferences("MisPrefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putInt("idUsuarioLogueado", userId);
                    editor.apply();

                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Error al obtener el ID del usuario", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
            }
        });

        btnRegistrar.setOnClickListener(view -> {
            startActivity(new Intent(LoginActivity.this, RegistroActivity.class));
        });
    }
}
