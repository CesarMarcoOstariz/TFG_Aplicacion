package com.example.tfg;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.TextView;
import java.util.Locale;

public class FragmentCalendario extends Fragment {
    private CalendarView calendarView;
    private TextView tvActividadesDia;
    private DBHelper dbHelper;
    private int idUsuario;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_calendario, container, false);
        calendarView = view.findViewById(R.id.calendarView);
        tvActividadesDia = view.findViewById(R.id.tvActividadesDia);
        dbHelper = new DBHelper(getContext());

        SharedPreferences prefs = requireActivity().getSharedPreferences("MisPrefs", Context.MODE_PRIVATE);
        idUsuario = prefs.getInt("idUsuarioLogueado", -1);

        calendarView.setOnDateChangeListener((view1, year, month, dayOfMonth) -> {
            String fechaSeleccionada = String.format(Locale.getDefault(),
                    "%04d-%02d-%02d", year, (month + 1), dayOfMonth);

            mostrarActividadesDelDia(fechaSeleccionada);
        });


        return view;
    }

    private void mostrarActividadesDelDia(String fecha) {
        if (idUsuario == -1) return;

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT a.nombre, a.fecha, a.hora, a.lugar " +
                        "FROM actividades a " +
                        "INNER JOIN usuario_actividades ua ON a.id = ua.idActividad " +
                        "WHERE ua.idUsuario = ? AND a.fecha = ?",
                new String[]{String.valueOf(idUsuario), fecha}
        );

        StringBuilder sb = new StringBuilder();
        while (cursor.moveToNext()) {
            String nombre = cursor.getString(0);
            String fechaAct = cursor.getString(1);
            String hora = cursor.getString(2);
            String lugar = cursor.getString(3);

            sb.append(nombre).append(" - ").append(fechaAct)
                    .append(" - ").append(hora).append(" - ").append(lugar).append("\n");
        }
        cursor.close();
        db.close();

        if (sb.length() == 0) {
            sb.append("No te has apuntado a nada para este día");
        }
        tvActividadesDia.setText(sb.toString());
    }

}
