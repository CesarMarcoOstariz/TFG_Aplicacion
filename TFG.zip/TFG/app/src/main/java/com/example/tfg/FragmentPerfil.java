package com.example.tfg;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class FragmentPerfil extends Fragment {
    private TextView tvNombre, tvApodo, tvEdad, tvActividades, tvComentarios;
    private EditText etComentario;
    private Button btnAgregarComentario;
    private DBHelper dbHelper;
    private int idUsuario;
    private ImageView ivFotoPerfil;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private Uri photoUri;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);
        tvNombre = view.findViewById(R.id.tvNombre);
        tvApodo = view.findViewById(R.id.tvApodo);
        tvEdad = view.findViewById(R.id.tvEdad);
        tvActividades = view.findViewById(R.id.tvActividades);
        tvComentarios = view.findViewById(R.id.tvComentarios);
        etComentario = view.findViewById(R.id.etComentario);
        btnAgregarComentario = view.findViewById(R.id.btnAgregarComentario);

        dbHelper = new DBHelper(getContext());

        SharedPreferences prefs = requireActivity().getSharedPreferences("MisPrefs", Context.MODE_PRIVATE);
        idUsuario = prefs.getInt("idUsuarioLogueado", -1);

        cargarDatosUsuario();
        cargarComentarios();
        agregarComentario();

        return view;
    }

    private void cargarDatosUsuario() {
        if (idUsuario == -1) return;

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        Cursor cursorAct = null;

        try {
            cursor = db.rawQuery("SELECT * FROM usuarios WHERE id=?", new String[]{String.valueOf(idUsuario)});
            if (cursor.moveToFirst()) {
                String nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombre"));
                String apodo = cursor.getString(cursor.getColumnIndexOrThrow("apodo"));
                int edad = cursor.getInt(cursor.getColumnIndexOrThrow("edad"));
                tvNombre.setText(nombre);
                tvApodo.setText(apodo);
                tvEdad.setText(String.valueOf(edad));
            }

            String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
            cursorAct = db.rawQuery(
                    "SELECT a.nombre FROM actividades a " +
                            "INNER JOIN usuario_actividades ua ON a.id = ua.idActividad " +
                            "WHERE ua.idUsuario = ? AND a.fecha >= ? LIMIT 5",
                    new String[]{String.valueOf(idUsuario), currentDate});

            StringBuilder sbActividades = new StringBuilder();
            while (cursorAct.moveToNext()) {
                sbActividades.append(cursorAct.getString(0)).append("\n");
            }
            tvActividades.setText(sbActividades.toString());

        } finally {
            if (cursor != null) cursor.close();
            if (cursorAct != null) cursorAct.close();
            db.close();
        }
    }

    private void cargarComentarios() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(
                    "SELECT texto FROM comentarios_perfil WHERE idUsuarioDestino=? ORDER BY fecha DESC LIMIT 5",
                    new String[]{String.valueOf(idUsuario)}
            );

            StringBuilder sb = new StringBuilder();
            while (cursor.moveToNext()) {
                sb.append("- ").append(cursor.getString(0)).append("\n");
            }
            tvComentarios.setText(sb.toString());

        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    private void agregarComentario() {
        btnAgregarComentario.setOnClickListener(v -> {
            String comentario = etComentario.getText().toString().trim();
            if (!comentario.isEmpty()) {
                String fecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("idUsuarioAutor", idUsuario);
                values.put("idUsuarioDestino", idUsuario);
                values.put("texto", comentario);
                values.put("fecha", fecha);

                long result = db.insert("comentarios_perfil", null, values);
                db.close();

                if (result != -1) {
                    etComentario.setText("");
                    Toast.makeText(getContext(), "Comentario agregado", Toast.LENGTH_SHORT).show();
                    cargarComentarios();
                } else {
                    Toast.makeText(getContext(), "Error al agregar el comentario", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "El comentario no puede estar vacío", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
